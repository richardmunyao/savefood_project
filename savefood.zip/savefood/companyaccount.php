
<!DOCTYPE html>
<html>
<head>
	<title>SAVE DONATE FOOD</title>
	<link href="css/bootstrap.min.css" rel="stylesheet"/>
	
</head>
<body>
<div class="container-fluid">
	<ul class="nav nav-pills pull-right" role="tablist">
		  <li type="button" class="btn"  role="presentation"><a href="index.html">Home</a></li>
		  <li type="button" class="btn" role="presentation"><a href="donate.html">Collection Points</a></li>
		  <li type="button" class="btn active" role="presentation"><a href="#">Taxpayers</a></li>
		  <li type="button" class="btn pull-right" role="presentation"><a href="contact.html">My Account</a></li>
    </ul>
</div>
<hr/>
<div class="jumbotron">
    Jumbotron class Goes Here
</div>
<div class="container">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <table class="table table-inverse">
       <thead class="thead-inverse">
    <tr>
      <th>Food ID</th>
      <th>Food Item</th>
      <th>Food Category</th>
      <th>County</th>
      <th>Location</th>      
      <th>Expiry Date</th>
      <th>Quantity</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
      <?php
require_once 'connectdb.php';
$select="SELECT * FROM `savefd` WHERE `status` = 'available'";
$run=$conn->query($select);
if($run->num_rows > 0){
while ($row = $run->fetch_assoc()){
    echo '<tr><td>'.$row ['id'].'</td><td>'
    .$row ['Food_Item'].'</td><td>'.
    $row ['Food_category'].'</td><td>'.
    $row ['County'].'</td><td>'.
    $row ['Location'].'</td><td>'
    .$row ['Expiry'].'</td><td>'.$row ['Quantity'].'</td></tr>';     
}
} 
?>    
  </tbody>
</table>
  
    </div>
</div>
</div>

</body>
</html>