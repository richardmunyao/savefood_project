<?php
require_once 'connectdb.php';

if(isset($_POST['username']) && isset($_POST['password'])&& isset($_POST['name'])&& isset($_POST['contact'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $name=$_POST['name'];
    $contact=$_POST['contact'];
    if(!empty($username) && !empty($password)&& !empty($name)&& !empty($contact)){
        
        $sql="INSERT INTO `ngos` (`username`, `password`, `name`, `contact`)VALUES('$username', '$password', '$name', '$contact')";
        if(mysqli_query($conn, $sql)){
            echo 'Success';
        }
 else {
     echo mysql_error();
 }
        
    }
 else {
        echo 'All fields should be filled';
    }
}


?>

