<?php
session_start();
$username=$_SESSION['username'];
?>
<?php
$name;
require_once 'connectdb.php';
$run=$conn->query("SELECT * FROM `ngos` WHERE `username`='$username'");
if($run->num_rows > 0){
if($row = $run->fetch_assoc()){
    $_SESSION['companyname']=$row['name'];
    
    $username=$row['username'];
    $name=$row['name'];
    $contact=$row['contact'];
}
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Hornbill</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--Include materialize css files-->
        
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="inputs/css/materialize.min.css" rel="stylesheet">
        
    </head>
    <body class="container-fluid" style="background-image: url('images/bg.png')"> 
        <div class="container">        
        <div class="row">
            <div class="center row">
                <div class="center col s8">ORGANIZATION SAVE FOOD ACCOUNT</div>
                <div class="col s4 right">                    
                    <a class="red-text" href="logout.php"><?php echo $name;?><i class="material-icons">settings_power</i></a>             
                    
                </div>
            </div>
            
            <div class="row">
              <div class="col s12">
                <ul class="tabs">
                  <li class="tab col s3 orange-text"><a class="active black-text" href="#home">My Profile</a></li>
                  <li class="tab col s3"><a class="black-text" href="#donations">Active Donations</a></li>
                  <li class="tab col s3"><a class="black-text" href="#activebid">Active Bids</a></li>
                  <li class="tab col s3"><a class="black-text" href="#penalties">Statistics</a></li>
                  <li class="tab col s3"><a class="black-text" href="#notifications">Notifications</a></li>
                </ul>
              </div>    
             </div>
            <div class="divider"></div> 
            
            <!--This is where the content of the page goes--> 
            
            <div id="home" class="row" style="width: 800px;margin: auto">
                <div class="center card">
                    <div class="card-title grey white-text">MY PERSONAL PROFILE</div>
                    <div class="card-content">                        
                        <div class="row">
                            <table>                                
                                <tr>
                                    <th>USERNAME</th>
                                    <th><?php echo $username;?></th>
                                </tr>
                                <tr>
                                    <th>NAME</th>
                                    <th><?php echo $name;?></th>
                                </tr> 
                                <tr>
                                    <th>CONTACT</th>
                                    <th><?php echo $contact;?></th>
                                </tr> 
                                
                            </table>                                                       
                        </div>                        
                    </div>
                </div>
            </div>
            <!--reservations page-->
            <div id="donations" class="row">
                <div class="col s12">
                    <h5 class="center green-text">Recent Donations</h2>
                </div>
                <table class="highlight">
                    <thead class="thead-inverse">
                        <tr class="cyan">
                          <th>Food ID</th>
                          <th>Food Item</th>
                          <th>Food Category</th>
                          <th>County</th>
                          <th>Location</th>      
                          <th>Expiry Date</th>
                          <th>Quantity</th>
                          <th>Action</th>
                        </tr>
                      </thead>

                    <tbody>
                      <?php
                        //require_once 'connectdb.php';
                        $select="SELECT * FROM `savefd` WHERE `status` = 0";
                        $runq=$conn->query($select);
                        if($runq->num_rows > 0){
                        while ($row = $runq->fetch_assoc()){
                            echo '<tr><td>'.$row ['id'].'</td><td>'
                            .$row ['Food_Item'].'</td><td>'.
                            $row ['Food_category'].'</td><td>'.
                            $row ['County'].'</td><td>'.
                            $row ['Location'].'</td><td>'
                            .$row ['Expiry'].'</td><td>'.$row ['Quantity'].'</td><td><a href="bid.php ?id='.$row['id'].'"><button type="submit" class="btn btn-success btn-xs">BID <span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span></button></a></td></tr>';     
                        }

                        } 
                        else{
                            echo '<font style="color:green"><tr><th colspan="7">There are currently no active  food donations in your tab</th></tr></font>';
                        }
                        ?>    
                    </tbody>
                </table>
            </div>
            <div id="activebid" class="row">
                These are the bids that are active.
                <table class="highlight">
                    <th>
                    <tr></tr>
                    </th>
                    <tbody>
                        <?php
                        $select="SELECT * FROM `savefd` WHERE `Taker` = '$name'";
                        $runq=$conn->query($select);
                        if($runq->num_rows > 0){
                        while ($row = $runq->fetch_assoc()){
                            echo '<tr><td>'.$row ['id'].'</td><td>'
                            .$row ['Food_Item'].'</td><td>'.
                            $row ['Food_category'].'</td><td>'.
                            $row ['County'].'</td><td>'.
                            $row ['Location'].'</td><td>'
                            .$row ['Expiry'].'</td><td>'.$row ['Quantity'].'</td></tr>';     
                        }

                        } 
                        else{
                            echo '<font style="color:green"><tr><th colspan="7">There are currently no active  food donations in your tab</th></tr></font>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div id="penalties" class="row">
                Penalties
            </div>
            <div id="notifications" class="row">
                Notifications
            </div>
        </div>
            
            <div class="row">
                 <footer class="page-footer black">                   
                    <div class="footer-copyright">
                      <div class="container center">
                      © 2016 Save Food and Save an hungry human.All rights Reserved                     
                      </div>
                    </div>
                  </footer>
            </div>
       </div>
        
        
        <!--Javascript-->
        <script src="inputs/js/jquery.min.js"></script>
        <script src="inputs/js/materialize.min.js"></script>
        <script>            
            $(document).ready(function(){
              $('ul.tabs').tabs();
            });        
        </script>
    </body>
</html>


