<?php
session_start();
require_once 'connectdb.php';
if(isset($_POST['username']) && isset($_POST['orgpassword'])){
    $username=$_POST['username'];
    $password=$_POST['orgpassword'];
    if(!empty($username) && !empty($password)){
        $run=$conn->query("SELECT*FROM `ngos` WHERE `username`='$username' AND `password`='$password'");
        if($run->num_rows==1){
            if($row=$run->fetch_assoc()){            
                $_SESSION['username']=$row['username'];
                //echo $_SESSION['username'];
                header('Refresh: 1; URL = savefoodaccount.php');
            }
            
            
        }
    else if($run->num_rows==0){
            echo "<script>alert('You are not a registered Organization With Us.')</script>";
            header("location:ngo.html");
        
    }
    }
 else {
        echo "<script>alert('All Field Should Be Filled')</script>";
        header('Refresh: 0; URL = ngo.html');
    }
}
?>



