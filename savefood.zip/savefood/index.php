<!DOCTYPE html>
<html>
<head>
	<title>SAVE DONATE FOOD</title>
	<link href="css/bootstrap.min.css" rel="stylesheet"/>
	
</head>
<body>

<div class="container">
	<ul class="nav nav-pills" role="tablist">
		  <li type="button" class="active btn"  role="presentation"><a href="#">Home</a></li>
		  <li type="button" class="btn" data-toggle="modal" data-target="#donationModal" role="presentation"><a href="#">Donate Food</a></li>
                  <li type="button" class="btn" data-toggle="modal" data-target="#ngoModal" role="presentation"><a href="login.html">NGOs</a></li>
		  <li type="button" class="btn" data-toggle="modal" data-target="#contactModal" role="presentation"><a href="#">Contact Us</a></li>
    </ul>
</div>
<hr/>
<div class="jumbotron">
	Welcome here
</div>
<div class="container">
    <!-- Button trigger modal -->


<!-- donation Modal -->
<div class="modal fade" id="donationModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">ENTER YOUR WILLING DONATION DETAILS</h4>
      </div>
      <div class="modal-body">
      <!--donation modal-->
      <div class="row">
      <div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1">@</span>
			  <input type="text" class="form-control" placeholder="Food Item" aria-describedby="basic-addon1">
			</div>
			</div>
		</div>

		<div class="row">
	        <div class="form-group">
	        <span class="input-group-addon" id="basic-addon1">Food Category</span>	        
			  <select class="form-control" id="food-category">
			    <option>Select Food Category</option>
			    <option>Agricultural</option>
			    <option>Manufactured</option>
			    <option>Home Made</option>		
			  </select>			  
			</div>
		</div>

		<div class="row">
		<div class="form-group">
		
		     <span class="input-group-addon" id="basic-addon1">Location</span>	
		     <div class="row">
		     <div class="col-sm-6">
		        <div class="input-group">
				  <span class="input-group-addon" id="basic-addon1">@</span>
				  <select class="form-control" id="food-category">
				 <option>Select County</option>
			    <option>Nairobi</option>
			    <option>Mombasa</option>
			    <option>Kisumu</option>
			    <option>Nakuru</option>
			    <option>Laikipia</option>
			    <option>Turkana</option>		
			  </select>			  
				</div>
			</div>
			<div class="col-sm-6">
		        <div class="input-group">
				  <span class="input-group-addon" id="basic-addon1">@</span>
				  <input type="text" class="form-control" placeholder="Town" aria-describedby="basic-addon1">
				</div>
			</div>

			</div>
			</div>
		</div>
		


		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1">@</span>
			  <input type="text" class="form-control" placeholder="Your Phone Number" aria-describedby="basic-addon1">
			</div>
		</div>
		</div>

		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1">@</span>
			  <input type="text" class="form-control" placeholder="Expiry-calendar" aria-describedby="basic-addon1">
			</div>
		</div>
		</div>

		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1">@</span>
			  <input type="text" class="form-control" placeholder="quantity" aria-describedby="basic-addon1">
			</div>
		</div>
		</div> 
        
        <!--End of donation modal-->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Post</button>
      </div>
    </div>
  </div>
</div>

<!-- NGO Modal -->
<div class="modal fade" id="ngoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Login</h4>
      </div>
      <div class="modal-body">
			       <div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1">@</span>
			  <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
			</div>
		</div>
		</div>

		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1">#</span>
			  <input type="password" class="form-control" placeholder="Password" aria-describedby="basic-addon1">
			</div>
		</div>	
		</div>
		<div class="row center-block"><input type="checkbox" checked="checked"> Remember me</div>
		<hr/>
		<div class="row-center">		     
            <button type="button" class="btn btn-primary center">LOGIN</button>
            
		</div>
	  </div>      
    </div>
  </div>
</div>
	
  

<!-- Contact Us Modal -->
<div class="modal fade" id="contactModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        ...Contact Modal
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
	


</div>

<script src="js/bootstrap.min.js"></script>
<script>
	$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').focus()
})
</script>
</body>
</html>