<?php
$mysql_host='localhost';
$mysql_user='root';
$pass="";
$db='savefood';


//create a connection
$conn=new mysqli($mysql_host,$mysql_user,$pass,$db);
//check connection
if($conn->connect_error){
	die("connection failed".$conn->connect_error);
}
?>
