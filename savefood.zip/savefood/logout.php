<?php
session_destroy();
header('Refresh: 0; URL = index.html');
?>