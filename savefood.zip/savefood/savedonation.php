<?php
require_once 'connectdb.php';

if(isset($_POST['fooditem']) && isset($_POST['foodcategory'])&& isset($_POST['county'])&& isset($_POST['town'])&& isset($_POST['phone'])&& isset($_POST['date'])&& isset($_POST['quantity'])){
    $fooditem=$_POST['fooditem'];
    $foodcategory=$_POST['foodcategory'];
    $county=$_POST['county'];
    $town=$_POST['town'];
    $phone=$_POST['phone'];
    $date=$_POST['date'];
    $quantity=$_POST['quantity'];
    if(!empty($fooditem) && !empty($foodcategory)&& !empty($county)&& !empty($town)&& !empty($phone)&& !empty($date)&& !empty($quantity)){
        
        $sql="INSERT INTO `savefd` (`Food_Item`, `Food_category`, `County`, `Location`, `Contact`, `Expiry`, `Quantity`, `Status`, `Taker`)VALUES('$fooditem', '$foodcategory', '$county', '$town', '$phone', '$date', '$quantity', 0, 'NA')";
        if(mysqli_query($conn, $sql)){
            echo '<script>alert("Thank You For your Sincere Donation.Welcome Again")</script>';
            header("Refresh:1;URL=about.html");
        }
 else {
     echo mysql_error();
 }
        
    }
 else {
        echo '<script>alert("All Field should be Filled.")</script>';
         header("Refresh:0;URL=donate.html");
    }
}


?>

