<?php

require_once 'connectdb.php';

if(isset($_POST['fooditem']) && isset($_POST['foodcategory'])&& isset($_POST['county'])&& isset($_POST['town'])&& isset($_POST['phone'])&& isset($_POST['date'])&& isset($_POST['quantity'])){
    $fooditem=$_POST['fooditem'];
    $foodcategory=$_POST['foodcategory'];
    $county=$_POST['county'];
    $town=$_POST['town'];
    $phone=$_POST['phone'];
    $date=$_POST['date'];
    $quantity=$_POST['quantity'];
    if(!empty($fooditem) && !empty($foodcategory)&& !empty($county)&& !empty($town)&& !empty($phone)&& !empty($date)&& !empty($quantity)){
        
        $sql="INSERT INTO `savefd` (`Food_Item`, `Food_category`, `County`, `Location`, `Contact`, `Expiry`, `Quantity`, `Status`, `Taker`)VALUES('$fooditem', '$foodcategory', '$county', '$town', '$phone', '$date', '$quantity', 'available', 'NA')";
        if(mysqli_query($conn, $sql)){
            
            echo "<script>alert('Thank you for your donation! :-)')</script>";
        }
 else {
     echo mysql_error();
 }
        
    }
 else {
        
        echo "<script>alert('All fields should be filled')</script>";
        
    }
    
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>SAVE DONATE FOOD</title>
	<link href="css/bootstrap.min.css" rel="stylesheet"/>
	<link href="css/custom.css" rel="stylesheet" />
	<style type="text/css">
	body{
			width: 100%;
		}
		:link{text-color: white;}

	</style>
	
</head>
<body background="media/dry.jpg">
<div class="container-fluid">
            <!-- Top menu -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
               <a class="navbar-brand" href="index.html">Save Food</a>
            </div>
            <nav class="navbar navbar-fixed-top  navbar-no-bg" role="navigation">               
                <div class="container">     
                    <div class="collapse navbar-collapse" id="top-navbar-1">                         
                        <ul class="nav navbar-nav navbar-right">
                            <li><a class="scroll-link" href="index.html">Home</a></li>
                            <li><a class="scroll-link white-text" href="donate.html">Donate</a></li>
                            <li><a class="scroll-link" href="ngologin.html">Partners</a></li>
                            <li><a class="scroll-link" href="about.html">About Us</a></li>                           
                        </ul>
                    </div>
                    <hr id="hr"/>
                </div>

            </nav>
 </div>
<br>
<br>

<!-- donation Modal -->
<div>
<div class="panel panel-default" style="width: 520px;margin: auto">
            <div class="panel-heading center-block">
              <h3 class="panel-title">DONATE</h3>
            </div>
<div class="panel-body">
    <form action="donate.php" method="POST">
      <div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1"></span>
			  <input name="fooditem" type="text" class="form-control" placeholder="Food Item" aria-describedby="basic-addon1">
			</div>
			</div>
	

		<div class="row">
	        <div class="form-group">
	        <span class="input-group-addon" id="basic-addon1">Food Category</span>	        
                <select class="form-control" id="food-category" name="foodcategory">
			    <option>Select Food Category</option>
			    <option>Agricultural</option>
			    <option>Manufactured</option>
			    <option>Home Made</option>		
			  </select>			  
			</div>
		</div>

		<div class="row">
		<div class="form-group">
		
		     <span class="input-group-addon" id="basic-addon1">Location</span>	
		     <div class="row">
		     <div class="col-sm-6">
		        <div class="input-group">
				  <span class="input-group-addon" id="basic-addon1"></span>
                                  <select class="form-control" id="food-category" name="county">
				 <option>Select County</option>
			    <option>Nairobi</option>
			    <option>Mombasa</option>
			    <option>Kisumu</option>
			    <option>Nakuru</option>
			    <option>Laikipia</option>
			    <option>Turkana</option>		
			  </select>			  
				</div>
			</div>
			<div class="col-sm-6">
		        <div class="input-group">
				  <span class="input-group-addon" id="basic-addon1"></span>
				  <input type="text" name="town" class="form-control" placeholder="Town" aria-describedby="basic-addon1">
				</div>
			</div>

			</div>
			</div>
		</div>
		


		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1"></span>
                          <input type="text" name="phone" class="form-control" placeholder="Your Phone Number" aria-describedby="basic-addon1">
			</div>
		</div>
		</div>

		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1"></span>
			  <input type="text" name="date" class="form-control" placeholder="Expiry-calendar" aria-describedby="basic-addon1">
			</div>
		</div>
		</div>

		<div class="row">
		<div class="form-group">
	        <div class="input-group">
			  <span class="input-group-addon" id="basic-addon1"></span>
			  <input type="text" name="quantity" class="form-control" placeholder="quantity" aria-describedby="basic-addon1">
			</div>
		</div>
		</div> 

		<div class="row">        
                  <button type="submit" class="btn btn-success center-block">Post</button>
                </div>
       </form>
      </div>


      </div>

</div>


</body>
</html>