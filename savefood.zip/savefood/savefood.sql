-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2016 at 07:28 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `savefood`
--

-- --------------------------------------------------------

--
-- Table structure for table `bidders`
--

CREATE TABLE IF NOT EXISTS `bidders` (
  `id` int(11) NOT NULL,
  `food_id` int(11) NOT NULL,
  `bidder` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `company_code` varchar(15) NOT NULL,
  `Company Name` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ngos`
--

CREATE TABLE IF NOT EXISTS `ngos` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `savefd`
--

CREATE TABLE IF NOT EXISTS `savefd` (
  `id` int(100) NOT NULL,
  `Food_Item` varchar(100) NOT NULL,
  `Food_category` varchar(100) NOT NULL,
  `County` varchar(100) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Contact` varchar(100) NOT NULL,
  `Expiry` varchar(100) NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Taker` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `savefd`
--

INSERT INTO `savefd` (`id`, `Food_Item`, `Food_category`, `County`, `Location`, `Contact`, `Expiry`, `Quantity`, `Status`, `Taker`) VALUES
(1, 'queen cakes', 'Manufactured', 'Nairobi', 'nairobi', '4455', '2016-01-02', '4 packets', '0', NULL),
(2, 'queen cakes', 'Manufactured', 'Nairobi', 'nairobi', '4455', '2016-01-02', '4 packets', '0', NULL),
(3, 'sugar', 'Agricultural', 'Mombasa', 'LAMU', '0700866545', '2016-01-02', '16', 'available', 'NA'),
(4, 'sugar', 'Agricultural', 'Mombasa', 'LAMU', '0700866545', '2016-01-02', '16', 'available', 'NA'),
(5, 'SOAP', 'Manufactured', 'Nakuru', 'NAKURU', '0727922132', '2016-01-02', '3', 'available', 'NA'),
(6, 'sugar', 'Agricultural', 'Nairobi', 'Kilele', '0727922132', '2016-01-02', '6', 'available', 'NA'),
(7, 'chapati', 'Home Made', 'Turkana', 'HALALE', '0727856453', '2016-01-02', '16', 'available', 'NA'),
(8, 'chapati', 'Home Made', 'Turkana', 'HALALE', '0727856453', '2016-01-02', '16', 'available', 'NA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bidders`
--
ALTER TABLE `bidders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`company_code`);

--
-- Indexes for table `ngos`
--
ALTER TABLE `ngos`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `savefd`
--
ALTER TABLE `savefd`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bidders`
--
ALTER TABLE `bidders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ngos`
--
ALTER TABLE `ngos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `savefd`
--
ALTER TABLE `savefd`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
