<?php
session_start();
?>
<?php
require_once 'connectdb.php';
$foodid=$_GET['id'];
$companyname=$_SESSION['companyname'];

$sql="UPDATE `savefd` SET `status`=1,`Taker`='$companyname' WHERE `id`='$foodid'";
if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    header('location:savefoodaccount.php');
}
?>
